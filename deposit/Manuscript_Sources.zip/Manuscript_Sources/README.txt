MANUSCRIPT SOURCES: VERSION 1.0
DOI: 10.5281/zenodo.23752103

The four top-level TeX sources match the four current public PDFs.
The prior_sources directory preserves historical sources for the two Prior PDFs.
Run: python3.12 BUILD_PDFS.py --output ../document-build
Dependencies: Python standard library and pdfLaTeX with the listed TeX packages.
The builder reads page counts from the final TeX log. Sources are self-contained.
PDF creation metadata can change byte hashes on another system.
The exact rational consequences checker is check_consequences_arithmetic.py.
This edition supersedes referee edition 3 of 28 October 2026; the numerical plan, source table and comparison history are unchanged; Appendix B adds the direct source reconstruction.
See REFEREE_EDITION_3_TO_CURRENT.diff for the manuscript changes from referee edition 3.
