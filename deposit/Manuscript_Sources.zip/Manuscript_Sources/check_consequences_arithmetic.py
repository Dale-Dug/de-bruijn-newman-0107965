#!/usr/bin/env python3
"""Check exact arithmetic in Further_Consequences; does not prove the terminal strip."""
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import json


def record(value):
    with localcontext() as context:
        context.prec = 70
        decimal = str(Decimal(value.numerator) / Decimal(value.denominator))
    return {"numerator": value.numerator, "denominator": value.denominator,
            "decimal_display_not_used_for_proof": decimal}


def main():
    root = Path(__file__).resolve().parent
    terminal_time = Fraction(22101, 204800)
    squared_halfwidth = Fraction(7902377963830536747158643, 2**96)
    cleanup = squared_halfwidth / 2
    bound = terminal_time + cleanup
    stated_bound = Fraction(427693072077942473661578098491,
                            3961408125713216879677197516800)
    prior_ceiling = Fraction(116397726408291, 10**15)
    difference = prior_ceiling - bound
    percentage = 100 * difference / prior_ceiling
    checks = {
        "terminal_time_exact_decimal": terminal_time == Fraction("0.1079150390625"),
        "terminal_squared_halfwidth_positive": squared_halfwidth > 0,
        "exact_endpoint_identity": bound == stated_bound,
        "endpoint_common_denominator": bound.denominator == 25 * 2**97,
        "cleanup_strict_enclosure": Fraction("0.0000498710162715") < cleanup < Fraction("0.0000498710162716"),
        "endpoint_strict_enclosure": Fraction("0.1079649100787715") < bound < Fraction("0.1079649100787716"),
        "strict_displayed_bound": bound < Fraction("0.107964910079") < Fraction("0.107965"),
        "ceiling_difference_strict_enclosure": Fraction("0.008432816329519") < difference < Fraction("0.008432816329520"),
        "percentage_rounds_to_7_24483": Fraction("7.244825") < percentage < Fraction("7.244835"),
        "contraction_zero_at_endpoint": squared_halfwidth - 2 * (bound - terminal_time) == 0,
    }
    if not all(checks.values()):
        raise SystemExit("Arithmetic failed: " + ", ".join(k for k, ok in checks.items() if not ok))
    receipt = {
        "schema": "FURTHER_CONSEQUENCES_EXACT_ARITHMETIC_V1",
        "status": "PASS",
        "doi": "10.5281/zenodo.23752103",
        "scope": "Exact rational consequences only. No terminal-strip proof, source reconstruction, full replay, or end-to-end Lean verification is claimed.",
        "terminal_time": record(terminal_time),
        "terminal_squared_halfwidth": record(squared_halfwidth),
        "full_cleanup_time": record(cleanup),
        "endpoint": record(bound),
        "prior_comparison_ceiling": record(prior_ceiling),
        "ceiling_difference": record(difference),
        "percentage_reduction": record(percentage),
        "checks": checks,
    }
    (root / "CONSEQUENCES_ARITHMETIC.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "checks": len(checks), "scope": receipt["scope"]}, indent=2))


if __name__ == "__main__":
    main()
