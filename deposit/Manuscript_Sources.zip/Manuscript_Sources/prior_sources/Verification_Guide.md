# The result and the supplied files

This deposit accompanies *Correlated translated probes and the bound $\Lambda<0.149396$ for the de Bruijn--Newman constant*, prepared as version 1.0. Its exact final ceiling is $$U=\frac{18674384228461}{125000000000000}
=0.149395073827688.$$

Read the main paper first, then *Analytic Foundations*. The latter reproduces the pinned one-point source proof and sharp translated geometry. The exact scientific archive is the executable source of the finite inequalities.

The earlier DOI 10.5281/zenodo.22626161 identifies a different fixed-time paper. Its 27 evidence volumes are **not required** to run this time-zero proof. Do not assign that earlier DOI to this new deposit.

## Three distinct levels of verification

1.  **Integrity:** sizes and SHA-256 values identify the files and reject accidental corruption. This says nothing by itself about their mathematical correctness.

2.  **Numerical regeneration:** the supplied programs recreate the wall, both complete probe lanes, translated gains, direct cross-checks, exact kernel inequalities and the final comparison. Stored PASS markers are not numerical premises of the default replay.

3.  **Analytic review:** the infinite-domain reductions, approximation extension, derivative remainder, zero dynamics, collisions and first-contact proof must be read and checked mathematically. They are not mechanically proved by the numerical run. The original Platt--Trudgian finite-RH computation is a cited published theorem, not regenerated here.

The work has not undergone external peer review or proof-assistant formalisation. Both transcendental lanes use the same Arb/FLINT library. Their different precision and construction choices do not constitute independent libraries.

# Contextual references and this editorial revision {#contextual-references-and-this-editorial-revision .unnumbered}

The main manuscript now distinguishes the reported preprint bounds of Gomila, the author's earlier Zenodo paper, and Gordon from the published mathematical inputs. Platt--Trudgian's $0.2$ corollary is also included in the historical comparison. Gordon's formal companion is described as partial, with explicit analytic hypotheses; its results are not proof inputs.

This is a pre-deposit editorial revision of the same proposed version 1.0. The exact ceiling, numerical source, certificate histories and `Proof_and_Replay.zip` are unchanged. The outer publication hashes are renewed because the manuscript and editorial files changed. The editorial checks are not a new mathematical replay or external peer review.

# Quick integrity check

Keep all the individual deposit files in one directory and run:

    python3 Verify_Deposit.py --check-only

This requires Python 3.10 or later. It verifies the listed publication and supplement identities. Expected marker:

    ZENODO_DEPOSIT_INTEGRITY_PASS

**This command does not regenerate any numerical inequality.**

The outer delivery folder named `AUTHOR/` is for the depositor, not a public proof input. It is not included in the deposit-level manifest.

# Complete numerical replay

## Supported execution profile

Use **CPython 3.13 on Linux x86_64**, matching the included binary runtime. The audit used CPython 3.13.5. The unchanged scientific archive includes python-flint 0.8.0 and its native FLINT/GMP/MPFR libraries and notices. No network access is needed by the replay once the files and Python are present.

Do not use `python -O`, suppress assertions, change the sources, or substitute a different numerical library while calling the execution the supplied profile. MacOS, Windows, ARM and other Python versions are not qualified by this release. A suitably configured Linux x86_64 environment is required; no untested Docker image or container digest is claimed.

The numerical stages use at most two workers concurrently. Allow several gigabytes of free disk for expanded sources, evidence and outputs. This is operational headroom, not a measured minimum-memory theorem. The observed times are recorded in the receipts and are not a speed guarantee for another machine.

## One-command route

Run from the directory of all public deposit files, with a new output directory outside it:

    python3.13 Verify_Deposit.py --replay --output ../replay_0149396

The wrapper first verifies the deposit, safely extracts `Proof_and_Replay.zip`, and launches its default replay. It refuses an output directory inside the immutable deposit or a nonempty existing output.

Expected final numerical marker:

    ZENODO_FULL_NUMERICAL_REPLAY_PASS

The endpoint must be exactly:

    18674384228461/125000000000000

## Direct supplement route

Alternatively, extract `Proof_and_Replay.zip` normally and run:

    cd Proof_and_Replay
    python3.13 REPLAY.py --output ../replayed_0149396

The supplement's default command does **not** use saved numerical results. It extracts the unchanged scientific archive and runs its full parent and joint production, then executes the new final-comparison layer.

# What the default run does

The immutable numerical source retains its historical intermediate endpoint $0.149398159734722$. That source is deliberately not edited merely to print the new headline. Its results become inputs to the separately versioned 128-substep final comparison, which proves the stronger endpoint.

The sequence is:

-   Verify all scientific source and embedded-parent manifests.

-   Regenerate both complete localisation-wall calculations.

-   Regenerate all 3,648 one-point probe rectangles in each lane, including the infinite-frequency interval and every source/error allowance.

-   Recheck the exact kernel catalogue, source algebra, direct physical sums and the separate time-zero xi/digamma comparison.

-   Regenerate 73,568 paired source cases in each joint-probe lane, including coefficient mismatch, denominator caps, source seams and truncation seams.

-   Reconstruct the complete parent and joint rational gates.

-   Run the final primary and alternative comparisons at 128 substeps per source cell. Independently check every recorded rate, join, domain, self-pair cap, upward endpoint and terminal logarithm.

-   Reject representative corrupted mathematical histories and verify sources are unchanged.

The exact final histories each contain 76,491 comparison records. The main source's 192/256-bit probe lanes and 256/384-bit wall lanes share Arb/FLINT. The final layer and its independent history checker use Python integers and fractions.

Some stronger parent inequalities are selected from the tighter valid lane, after their complete matching domains are verified. The final headline is not asserted independently from the weaker original parent lane. It does not average incompatible estimates or choose favourable sampled values.

# Evidence and output locations

Inside `Proof_and_Replay.zip`:

::: longtable
@ \>

p(- 2) \* \>

p(- 2) \* @

Location

&

Purpose

\
`Sources/Scientific_Source.zip` & Unchanged joint source with complete embedded parent and runtime\
`Sources/final/` & New exact final-comparison producer and independent history checker\
`Sources/Final_Comparison_Source.zip` & Sealed copy of that final layer\
`Evidence/numerical/` & Fresh full numerical production and its parent outputs\
`Evidence/final/` & Fresh primary/alternate endpoint histories and receipt\
`Audit/` & Opportunity audit, provenance bindings, release verification boundary\
`REPLAY.py` & Default full regeneration, with explicit integrity-only mode\
`MANIFEST.json` & Supplement file identities\
:::

The underlying programs print earlier stage-specific bounds and markers. They are intermediate results, not conflicting publication headlines. The final deposit endpoint is fixed in the separate comparison receipt.

The original laboratory's Python startup printed an unrelated spreadsheet warm-up warning during some subprocess starts. The numerical programs continued, completed with exit code zero and produced their checked receipts. Those logs are preserved rather than silently cleaned. Any nonzero mathematical-stage return code or absent completion receipt is a failed/incomplete run.

# The optional reuse mode has a different scope

`REPLAY.py --reuse-numerical <directory>` is an audit shortcut, not the default. It verifies a complete preceding numerical run, revalidates its hashes and mathematical interfaces, and reruns the final exact layer. Its marker is:

    ZENODO_EXACT_LAYER_REPLAY_PASS

That marker **does not mean** numerical producers ran again in that invocation. Do not describe a reuse run as a complete fresh numerical replay.

The release audit executed the original complete numerical command without reuse and then the sealed new exact layer against those freshly generated outputs. Packaging integrity and the reuse interface were tested separately. The receipts identify each execution boundary.

# Opportunity audit and scope

The final check compared 4, 8, 16, 32, 64 and 128 substeps while leaving every functional source estimate unchanged. At 128, both exact arithmetic routes give $0.149395073827688$. This is the frozen public release, not an optimum over all schedules, kernels or source terms.

No new stronger source theorem was assumed to obtain those digits. No claim of $\Lambda<0.09$, RH, worldwide priority or external acceptance is attached to this deposit.

# Reviewer checklist

Review the larger-height approximation and its full Gaussian ranges; the complex-neighbourhood derivative allowance and complete cutoff-pair debit; the finite-head propagation and wall; the common-phase surplus with unequal coefficients and denominators; the two types of spatial seam; the exact self-pair subtraction; and the first-contact treatment of collisions and time knots. Verify the final numerical histories against their exact source floors and domains.

A successful numerical replay supports those written arguments. It does not replace their mathematical review.

# Versioning and future corrections

This first prepared public release is version 1.0 of a separate time-zero paper. Use the new version-specific Zenodo DOI for this exact theorem and evidence. The concept DOI identifies its evolving version family.

For a changed mathematical source, witness, error bound or endpoint, create a new version with an explicit change record. Preserve the old scientific bytes. Metadata-only corrections can be made separately. Never reuse the old fixed-time paper's DOI as the identifier of this object.

Read `LICENSES_AND_RIGHTS.md` for the mixed licence scopes. Repository licence selection and final publication are author decisions; nothing in this package has been automatically submitted or published.
