#!/usr/bin/env python3
"""Build the companion PDF from the TeX file beside this script."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True,
                        help='Build directory, separate from the source directory.')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    output = args.output.resolve()
    if output == source:
        parser.error('The build directory must differ from the source directory.')
    if not shutil.which('pdflatex'):
        parser.error('pdflatex and the TeX packages in the document preamble are required.')
    output.mkdir(parents=True, exist_ok=True)
    name = 'Further_Consequences'
    tex = source / (name + '.tex')
    original = tex.read_bytes()
    (output / tex.name).write_bytes(original)
    for step in range(1, 4):
        result = subprocess.run(['pdflatex', '-interaction=nonstopmode',
                                 '-halt-on-error', tex.name], cwd=output,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (output / f'pass-{step}.txt').write_text(result.stdout)
        if result.returncode:
            raise SystemExit(result.stdout[-8000:])
    log = (output / (name + '.log')).read_text()
    issues = [line for line in log.splitlines() if 'Overfull' in line or
              'undefined references' in line.lower() or 'undefined citations' in line.lower()]
    if issues:
        raise SystemExit('\n'.join(issues))
    pdf = output / (name + '.pdf')
    if tex.read_bytes() != original:
        raise SystemExit('The source changed during compilation.')
    receipt = {'status': 'BUILD_PASS', 'source_sha256': hashlib.sha256(original).hexdigest(),
               'pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
               'pdf_bytes': pdf.stat().st_size,
               'scope': 'Document build only; does not establish the terminal-strip premise.'}
    (output / 'BUILD_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
