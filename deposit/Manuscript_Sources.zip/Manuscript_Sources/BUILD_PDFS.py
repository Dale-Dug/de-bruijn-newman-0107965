#!/usr/bin/env python3
"""Build the current four manuscript sources in separate directories."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def build(sources, output, names):
    if output.resolve()==sources.resolve() or sources.resolve() in output.resolve().parents:
        raise ValueError('Choose an output directory outside the source tree.')
    records=[]
    for name in names:
        source=sources/(name+'.tex')
        folder=output/name
        folder.mkdir(parents=True,exist_ok=True)
        for suffix in ('.aux','.out','.toc','.lof','.lot'):
            (folder/(name+suffix)).unlink(missing_ok=True)
        shutil.copyfile(source,folder/source.name)
        for n in range(1,4):
            run=subprocess.run(['pdflatex','-no-shell-escape','-interaction=nonstopmode',
                '-halt-on-error',source.name],cwd=folder,stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,text=True)
            (folder/f'pass-{n}.txt').write_text(run.stdout)
            if run.returncode:
                print(run.stdout[-9000:],file=sys.stderr)
                raise RuntimeError('Compilation failed: '+name)
        log=(folder/(name+'.log')).read_text(errors='replace')
        problems=[]
        for expression in [r'Overfull \\[hv]box',r'LaTeX Warning:.*undefined',
                           r'LaTeX Warning: There were undefined references',
                           r'LaTeX Warning: Label.*multiply defined']:
            problems.extend(re.findall(expression,log))
        pdf=folder/(name+'.pdf')
        match=re.search(r'Output written on .*?\((\d+) pages?', log, re.S)
        if not match:
            raise RuntimeError('Cannot identify final PDF page count in TeX log: '+name)
        pages=int(match.group(1))
        if problems:
            raise RuntimeError('Final LaTeX log needs review: '+name+': '+str(problems))
        record={'file':pdf.name,'pages':pages,'source_sha256':sha(source),
            'pdf_sha256':sha(pdf),'pdf_bytes':pdf.stat().st_size,
            'final_log_problems':problems,'visual_review':'pending'}
        records.append(record)
        print(json.dumps(record),flush=True)
    (output/'BUILD_RECEIPT.json').write_text(json.dumps({'documents':records},indent=2)+'\n')
    return records

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sources',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--names',nargs='+',default=['Unconditional_0107965','Matched_Source_Supplement',
        'Further_Consequences','Verification_Guide'])
    a=p.parse_args()
    build(a.sources.resolve(),a.output.resolve(),a.names)
